class Greeting extends Component {
    render() {
      return <h1>Hello, {this.props.name}!</h1>;
    }
  }
  <!DOCTYPE html>
<html>
<head>
    <title> Add New Album</title>

     
      <div class="header">
          <h1>Add New Album</h1>
          <hr>
          
          <html>
          <body>
          <p class="mix"></p>
        </body>
        </html>
        
     
    <p>Album Art</p>
    <html>
<body>

<h2></h2>
<img src="https://2.bp.blogspot.com/-Nc9YO_-F8yI/TcSIAB-nR-I/AAAAAAAAAGI/hPkuxqkqVcU/s1600/music-clipartMUSIC1.jpg" alt="Trulli" width="250" height="250">

</body>
</html>
    
          <html>
    <body>
        <p></p>

<form action="/action_page.php">
  <input type="file" id="myFile" name="filename">
  <input type="submit">
</form>
    </body> 
    </html> 
          
        </div>
        <hr>
      
      
        <p>
            Album Details
        </p>
        <style>
            .flex-container {
              display: flex;
              background-color:white;
            }
            
            .flex-container > div {
              background-color: white;
              margin: 50px;
              padding: 20px;
              font-size: 30px;
            }
            </style>
            </head>
            <body>
            
                <style>
                    .flex-container {
                      display: flex;
                      background-color: white;
                    }
                    
                    .flex-container > div {
                      background-color: #f1f1f1;
                      margin: 30px;
                      padding: 10px;
                      font-size: 30px;
                    }
                    </style>
            
            <div class="flex-container">
              
              <form>
                <label for="fname">Artist</label><br>
                <input type="text" id="fname" name="fname"><br>
                </form>
                <label for="lname">Genre</label><br>
                <input type="text" id="lname" name="lname"> 
                
            </div>
            <div class="flex-container">
              
                <form>
                  <label for="fname">Producer</label><br>
                  <input type="text" id="fname" name="fname"><br>
                  </form>
                  <label for="lname">Release</label><br>
                  <input type="text" id="lname" name="lname"> 
              </div>
      
        <button type="button">CANCEL</button>
        <button type="button">ADD</button>
      
</head>
<body>

    
</body>
</html>